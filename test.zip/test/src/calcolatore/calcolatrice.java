package calcolatore;

public class calcolatrice {
	public double somma(double a, double b) {
		return a+b;
	}
	public double sottrazione(double a, double b) {
		return a-b;
	}
	public double divisione(double a, double b) {
		return a/b;
	}
	public double moltiplicazione(double a, double b) {
		return a*b;
	}
}
