package srl.neotech.academy.java07;



public class Java07_01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
        
		for(int i=0;i<=10;i++) {
			System.out.println(i);
        }
       
	}

}
