package srl.neotech.academy.java06;

public class Vampiro extends Mostro{

	@Override
	public String caccia() {
		// TODO Auto-generated method stub
		return super.caccia();
	}

	@Override
	public String vainLetargo() {
		// TODO Auto-generated method stub
		return super.vainLetargo();
	}

	@Override
	public String attacca() {
		// TODO Auto-generated method stub
		return super.attacca()+" mordi";
	}

	@Override
	public String difendi() {
		// TODO Auto-generated method stub
		return super.difendi()+ " trasforma in nebbia";
	}

	@Override
	public String muori() {
		// TODO Auto-generated method stub
		return super.muori();
	}

}
