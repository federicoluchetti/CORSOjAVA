package srl.neotech.academy.java06;

public interface Giocatore {
public String attacca();
public String difendi();
public String muori();
}
