package srl.neotech.academy.java06;

public class Mago extends Umano{

	@Override
	public String mangia() {
		// TODO Auto-generated method stub
		return super.mangia();
	}

	@Override
	public String dormi() {
		// TODO Auto-generated method stub
		return super.dormi();
	}

	@Override
	public String attacca() {
		// TODO Auto-generated method stub
		return super.attacca()+" palla di fuoco";
	}

	@Override
	public String difendi() {
		// TODO Auto-generated method stub
		return super.difendi()+" scudo magico";
	}

	@Override
	public String muori() {
		// TODO Auto-generated method stub
		return super.muori();
	}

}
