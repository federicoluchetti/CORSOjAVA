package srl.neotech.academy.java03;

public class Volontario extends Impiegato{
	@Override
	public String getNome() {
		// TODO Auto-generated method stub
		return super.getNome();
	}

	@Override
	public void setNome(String nome) {
		// TODO Auto-generated method stub
		super.setNome(nome);
	}

	@Override
	public String getIndirizzo() {
		// TODO Auto-generated method stub
		return super.getIndirizzo();
	}

	@Override
	public void setIndirizzo(String indirizzo) {
		// TODO Auto-generated method stub
		super.setIndirizzo(indirizzo);
	}

	@Override
	public String getTelefono() {
		// TODO Auto-generated method stub
		return super.getTelefono();
	}

	@Override
	public void setTelefono(String telefono) {
		// TODO Auto-generated method stub
		super.setTelefono(telefono);
	}

	public double getPaga() {
		return 600;
		
	}
}
