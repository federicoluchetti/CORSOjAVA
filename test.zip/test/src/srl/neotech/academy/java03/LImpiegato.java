package srl.neotech.academy.java03;


public interface LImpiegato {

}
