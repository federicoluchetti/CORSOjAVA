package srl.neotech.academy.java10;

import java.util.Scanner;

public class Java10_04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		System.out.println("digita un numero:");
		int UnNumero=scanner.nextInt();
		System.out.println(Math.sqrt(UnNumero));
		scanner.close();
		


}
}