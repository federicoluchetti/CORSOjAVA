package srl.neotech.esercizio4.java;

public class Giochiamo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Eroe mioEroe=new Eroe();
		Vampiro dracula=new Vampiro();
		Licantropo gino=new Licantropo();
		mioEroe.combatti();
		dracula.azzanna();
		
		mioEroe.GetForza();
		gino.azzanna();
		
	
	}

}
