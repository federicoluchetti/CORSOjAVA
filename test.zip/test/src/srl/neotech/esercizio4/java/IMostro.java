package srl.neotech.esercizio4.java;

public interface IMostro extends IPersonaggio {
public void azzanna();

}
