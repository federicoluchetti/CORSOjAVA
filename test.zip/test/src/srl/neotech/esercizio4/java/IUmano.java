package srl.neotech.esercizio4.java;

public interface IUmano extends IPersonaggio{
public void combatti();

}