package srl.neotech.esercizio4.java;

public interface IPersonaggio {
	public String GetForza();
	}
