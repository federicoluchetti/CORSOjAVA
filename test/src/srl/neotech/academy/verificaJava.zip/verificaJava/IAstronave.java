package srl.neotech.academy.verificaJava;

public interface IAstronave {
public String decolla(int velocità);
public String accellera(int velocità);
public String decellera(int velocità);
}



























 